package com.example.sumatifroom_desiana_ganjil.room

class Constant {
    companion object{
        const val TYPE_READ = 0
        const val TYPE_CREATE = 1
        const val TYPE_UPDATE = 2
    }
}